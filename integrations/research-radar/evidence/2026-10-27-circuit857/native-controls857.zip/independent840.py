from pathlib import Path
from itertools import product, combinations
from collections import defaultdict, Counter
from math import gcd, lcm
from functools import reduce
import datetime, json, sys, time, traceback
import sympy as sp

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'independent'
OUT.mkdir(exist_ok=True)
stats=Counter()
started=time.monotonic()
def mv(M,x): return tuple(sum(a*b for a,b in zip(row,x)) for row in M)
def primitive(v):
 g=reduce(gcd,map(abs,v));v=tuple(a//g for a in v)
 return tuple(-a for a in v) if next(a for a in v if a)<0 else v
def circuits23(M):
 cols=list(zip(*M));out=[]
 for j,v in enumerate(cols):
  if v==(0,0):out.append(tuple(int(k==j) for k in range(3)))
 ds={(i,j):cols[i][0]*cols[j][1]-cols[i][1]*cols[j][0] for i,j in combinations(range(3),2)}
 for (i,j),d in ds.items():
  if d==0 and cols[i]!=(0,0) and cols[j]!=(0,0):
   row=next(row for row in M if row[i] or row[j]);v=[0]*3;v[i]=row[j];v[j]=-row[i];out.append(primitive(v))
 if all(ds.values()):out.append(primitive((ds[1,2],-ds[0,2],ds[0,1])))
 return list(ds.values()),out
def symbolic_circuits(M):
 A=sp.Matrix(M);out=[]
 for k in range(1,min(A.rows+1,A.cols)+1):
  for J in combinations(range(A.cols),k):
   ns=A[:,J].nullspace()
   if len(ns)!=1 or not all(ns[0]):continue
   scale=lcm(*(int(a.q) for a in ns[0]));v=[0]*A.cols
   for j,a in zip(J,ns[0]):v[j]=int(a*scale)
   out.append(primitive(v))
 return out
def points_by_rhs(M,cap,lower=None):
 lower=lower or (0,)*len(cap);F=defaultdict(list)
 for x in product(*(range(l,u+1) for l,u in zip(lower,cap))):F[mv(M,x)].append(x)
 return F
def conv(X,Y):return Counter(tuple(a+b for a,b in zip(x,y)) for x in X for y in Y)
def witnesses(M,cs,tag,log):
 n=len(M[0]);r=len(M)
 for c in cs:
  assert mv(M,c)==(0,)*r
  for i,ci in enumerate(c):
   if abs(ci)<2:continue
   c=tuple(-x for x in c) if c[i]<0 else c
   cap=tuple(map(abs,c));F=points_by_rhs(M,cap);p=tuple(max(x,0) for x in c);q=tuple(max(-x,0) for x in c)
   pts=[tuple(a-k*int(j==i) for j,a in enumerate(p)) for k in (2,1,0)]
   rhs=[mv(M,x) for x in pts];actual=[F[b] for b in rhs]
   counts=list(map(len,actual));assert counts==[1,1,2],(M,c,i,counts)
   assert actual[0]==[pts[0]] and actual[1]==[pts[1]]
   assert set(actual[2])=={p,q}
   mid=conv(actual[1],actual[1]);cross=conv(actual[0],actual[2]);defect={v:mid[v]-cross[v] for v in mid.keys()|cross.keys() if mid[v]!=cross[v]}
   exponent=tuple(a+b for a,b in zip(pts[0],q))
   assert defect=={exponent:-1},(M,c,i,defect)
   assert len(set(rhs))==3
   assert sum(bool(x) for x in cap)<=r+1
   stats['positive_witnesses']+=1
   stats['chosen_coefficient_eq2' if c[i]==2 else 'chosen_coefficient_gt2']+=1
   if all(a==0 or abs(a)>1 for a in c):stats['primitive_without_unit_entry']+=1
   if all(a%2 for a in c if a):stats['all_nonzero_coefficients_odd']+=1
   log.write(json.dumps(dict(tag=tag,M=M,c=c,i=i,cap=cap,rhs=rhs,counts=counts,negative_monomial_exponent=exponent))+'\n')
def coefficient_checks(M,D,tag):
 n=len(M[0]);lower=tuple(-2 if j%2==0 else 1 for j in range(n));cap=tuple(a+2 for a in lower)
 F=points_by_rhs(M,cap,lower);sq={b:conv(X,X) for b,X in F.items()}
 for bm,bp in combinations(F,2):
  added=tuple(a+b for a,b in zip(bm,bp))
  if any(a%2 for a in added):continue
  b0=tuple(a//2 for a in added)
  if b0 not in F:
   stats['even_index_empty_centers']+=1
   assert D%2==0,(tag,M,D,bm,b0,bp)
   continue
  cross=conv(F[bm],F[bp]);mid=sq[b0]
  assert all(mid[v]>=count for v,count in cross.items()),(tag,M,bm,b0,bp)
  stats['coefficient_triples_nonempty']+=1
def binary_all(M,expected,tag):
 n=len(M[0]);ok=True
 for cap in product((0,1),repeat=n):
  end=mv(M,cap)
  if any(a%2 for a in end):continue
  F=points_by_rhs(M,cap);mid=tuple(a//2 for a in end)
  # This checks the full binary box fiber, without importing the packet's mask search.
  if mid not in F:ok=False
  stats['binary_center_checks']+=1
 assert ok==expected,(tag,M,ok,expected)
def crafted():
 yield 'primitive_2_3_5',[[3,-2,0],[5,0,-2]]
 yield 'primitive_2_minus3_5',[[3,2,0],[5,0,-2]]
 yield 'primitive_allodd_3_5_7',[[5,-3,0],[7,0,-3]]
 for c in [(2,-3,5,7),(2,3,5,7),(-2,3,-5,7),(3,5,7,9)]:
  yield 'rank3_kernel_'+str(c),[[c[-1]*int(i==j) if j<3 else -c[i] for j in range(4)] for i in range(3)]
 yield 'zero_column_bad_rank3',[[3,-2,0,0,0],[5,0,-2,0,0],[0,0,0,1,0]]
 yield 'zero_column_odd_nontu',[[3,6,9,0],[0,1,1,0]]
 yield 'square_odd_3',[[3,2],[3,3]]
 yield 'square_even_2',[[2,1],[0,1]]
 yield 'square_even_4',[[2,0],[0,2]]
 yield 'square_odd_15',[[3,1,2],[0,5,1],[0,0,1]]
 yield 'all_zero_extra_columns',[[1,0,0,0],[0,1,0,0]]
try:
 with (OUT/'positive-witnesses.jsonl').open('w',encoding='utf-8') as log:
  for flat in product(range(-2,3),repeat=6):
   M=[list(flat[:3]),list(flat[3:])];ds,cs=circuits23(M);nz={abs(a) for a in ds if a}
   if not nz:stats['rank_deficient_excluded']+=1;continue
   stats['fullrank_2x3']+=1
   equi=len(nz)==1;D=next(iter(nz)) if equi else None
   assert equi==all(max(map(abs,c))==1 for c in cs),(M,ds,cs)
   stats['equimodular_2x3' if equi else 'nonequimodular_2x3']+=1
   witnesses(M,cs,'exhaustive_2x3',log)
   binary_all(M,equi and D%2==1,'exhaustive_2x3')
   if equi:coefficient_checks(M,D,'exhaustive_2x3')
  for tag,M in crafted():
   A=sp.Matrix(M);assert A.rank()==A.rows
   ds=[int(A[:,J].det()) for J in combinations(range(A.cols),A.rows)];nz={abs(a) for a in ds if a};equi=len(nz)==1;D=next(iter(nz)) if equi else None
   cs=symbolic_circuits(M)
   witnesses(M,cs,tag,log);binary_all(M,equi and D%2==1,tag)
   if equi:coefficient_checks(M,D,tag)
   stats['crafted_matrices']+=1
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started,stats=dict(stats),failures=[],scope='Exact finite falsification controls, not a proof. Independent standard-library circuit enumeration for 2x3; SymPy only for crafted cases.')
except BaseException as e:
 result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started,stats=dict(stats),failures=[repr(e)],traceback=traceback.format_exc())
(OUT/'RESULTS840.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
sys.exit(bool(result['failures']))
