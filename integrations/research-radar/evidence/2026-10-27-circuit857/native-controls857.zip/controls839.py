from pathlib import Path
from itertools import combinations,product
from collections import defaultdict,Counter
from math import gcd,lcm
from functools import reduce
import sympy as s
import json,datetime,hashlib
C=Path(__file__).parent
cases={'unit':[[1]],'odd3':[[3]],'odd5':[[5]],'even2':[[2]],'unit_sum':[[1,1]],'odd_sum':[[3,3]],'even_sum':[[2,2]],'odd_rank2':[[3,0,3],[0,1,1]],'even_rank2':[[2,0,2],[0,1,1]],'bad_odd_circuit':[[1,3]],'bad_even_circuit':[[1,2]],'bad_positive_circuit':[[1,-2]],'bad_zero_column':[[0,1,3]],'bad_all_odd_rank2':[[1,0,1],[0,1,3]],'bad_rank2_even_basis':[[1,0,1,1],[0,1,1,-1]],'nonTU_unimodular':[[1,2,3],[0,1,1]]}
def image(M,x):return tuple(sum(a*b for a,b in zip(row,x)) for row in M)
def fibers(M,cap):
 F=defaultdict(list)
 for x in product(*(range(a+1) for a in cap)):F[image(M,x)].append(x)
 return dict(F)
def circuits(M):
 r=len(M);n=len(M[0]);mat=s.Matrix(M)
 for k in range(1,min(r+1,n)+1):
  for J in combinations(range(n),k):
   N=mat[:,list(J)].nullspace()
   if len(N)!=1 or any(a==0 for a in N[0]):continue
   d=lcm(*(int(a.q) for a in N[0]));v=[int(a*d) for a in N[0]];g=reduce(gcd,map(abs,v));v=[a//g for a in v]
   c=[0]*n
   for j,a in zip(J,v):c[j]=a
   yield c
rows=[]
for name,M in cases.items():
 r=len(M);n=len(M[0]);mat=s.Matrix(M)
 minor_rows=[(J,int(mat[:,list(J)].det())) for J in combinations(range(n),r)]
 nonzero={abs(d) for J,d in minor_rows if d};assert nonzero
 equi=len(nonzero)==1;D=next(iter(nonzero)) if equi else None
 cs=list(circuits(M));assert equi==all(max(map(abs,c))==1 for c in cs)
 row=dict(name=name,M=M,nonzero_maximal_minor_magnitudes=sorted(nonzero),equimodular=equi,D=D,circuits=cs)
 if not equi:
  c=next(c for c in cs if max(map(abs,c))>=2);i=next(i for i,a in enumerate(c) if abs(a)>=2)
  if c[i]<0:c=[-a for a in c]
  cap=list(map(abs,c));F=fibers(M,cap);p=[max(a,0) for a in c];base=image(M,p);col=[row[i] for row in M]
  rhs=[tuple(a-k*b for a,b in zip(base,col)) for k in [2,1,0]]
  counts=[len(F.get(b,[])) for b in rhs];assert counts==[1,1,2]
  assert sum(a>0 for a in cap)<=r+1
  row['positive_witness']=dict(circuit=c,chosen_index=i,box_upper=cap,rhs=rhs,counts=counts,defect=counts[1]**2-counts[0]*counts[2])
 else:
  tested=equal=holes=0
  for width in [1,2]:
   F=fibers(M,[width]*n)
   conv={b:Counter(tuple(a+d for a,d in zip(x,y)) for x in X for y in X) for b,X in F.items()}
   for bm,bp in combinations(F,2):
    if any((a+b)%2 for a,b in zip(bm,bp)):continue
    b0=tuple((a+b)//2 for a,b in zip(bm,bp))
    if b0 not in F:holes+=1;assert D%2==0;continue
    cross=Counter(tuple(a+d for a,d in zip(x,y)) for x in F[bm] for y in F[bp])
    diff=[conv[b0][x]-cross[x] for x in conv[b0].keys()|cross.keys()]
    assert all(a>=0 for a in diff),(name,width,bm,b0,bp)
    tested+=1;equal+=not any(diff)
  row['finite_coefficient_controls']=dict(nonempty_triples=tested,equalities=equal,empty_centers=holes)
  if D%2==0:
   J,Bdet=next((J,d) for J,d in minor_rows if d)
   B=mat[:,list(J)]
   a=next(v for v in product([0,1],repeat=r) if any(v) and all(int(z)%2==0 for z in B*s.Matrix(v)))
   cap=[0]*n
   for j,v in zip(J,a):cap[j]=v
   F=fibers(M,cap);end=image(M,cap);rhs=[tuple([0]*r),tuple(z//2 for z in end),end]
   counts=[len(F.get(b,[])) for b in rhs];assert counts==[1,0,1]
   row['even_index_binary_witness']=dict(basis_columns=J,box_upper=cap,rhs=rhs,counts=counts)
 rows.append(row)
# Separate exhaustive SMALL matrix parity-halving check, not all matrices/theorem proof.
exhaustive=fullrank=0
for flat in product(range(-2,3),repeat=6):
 M=[flat[:3],flat[3:]]
 ds=[M[0][i]*M[1][j]-M[0][j]*M[1][i] for i,j in combinations(range(3),2)]
 nz={abs(d) for d in ds if d}
 if not nz:continue
 fullrank+=1
 expected=len(nz)==1 and next(iter(nz))%2==1
 masks=list(product([0,1],repeat=3));sums={a:image(M,a) for a in masks}
 halving=True
 for a,end in sums.items():
  if all(z%2==0 for z in end):
   target=tuple(z//2 for z in end)
   if not any(sums[b]==target and all(v<=w for v,w in zip(b,a)) for b in masks):halving=False;break
 assert expected==halving,(M,nz,halving)
 exhaustive+=1
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Exact finite controls only; universal classification rests on analytic proof838 and cited LMY inequality, not tests',rows=rows,exhaustive_rank2x3=dict(entry_set=[-2,-1,0,1,2],fullrank_matrices=fullrank,parity_halving_equivalence_passed=exhaustive),failures=0,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(C/'CONTROLS839.json').write_bytes((json.dumps(out,indent=2)+'\n').encode())
print(json.dumps(dict(cases=len(rows),bad_positive_witnesses=sum(not z['equimodular'] for z in rows),fullrank_small_matrices=fullrank,failures=0)))
