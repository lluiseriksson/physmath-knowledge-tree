# Separate post-synthesis observation — unreviewed

The positive common-component lower bound may have an exact dimension-only envelope, with sharpness already witnessed by a classical family. Do not confuse this with sharp complete trace/Umegaki contraction or claim a new classical theorem.

For d>=2 let K(y|i)=(1-delta_yi)/(d-1), R(y|i)=1/d, and P_s=(1-s)R+sK with0<=s<=1. As a dephase/classical channel on d-dimensional input, its ordinary trace coefficient is s/(d-1): any pair of distinct columns differs only at two coordinates, with total-variation distance s/(d-1). The finite measurement-channel formula already identified in Proposition35 gives positive CP common-component weight sum_y min_i P_s(y|i)=1-s.

With E the output dephasing channel and s=(d-1)r for0<=r<=1/(d-1), this matches1-(d-1)r. For a constraint eta_trace(Psi)<=r with r>=1/(d-1), the exclusion channel s=1 already gives coefficient0. Thus, if the general lower bound survives audit, its infimum over allowed prefixes and EB postprocessors with sufficiently large allowed output alphabet appears to equal max(0,1-(d-1)r). This uses an outcome alphabet of size d; it is not a sharpness statement for a fixed smaller output space.

This observation is outside the public1207 note and its finite planar Choi certificate. The classical Doeblin/Dobrushin comparison is likely prior; locate its theorem and attribution. The quantum lower-bound argument, the continuum recorded-posterior extension, and the common-component envelope need a unified scoped audit before any manuscript. A finite exact arithmetic table supports the family but does not establish worldwide novelty or optimality of the separate complete-contraction bound.

Also retain the representation distinction: finite-dimensional EB channels admit finite preparation descriptions, while replacing a continuum recorded instrument by a different finite description changes its posterior law. A finite channel representation by itself does not remove the recorded-outcome hypothesis in the original trajectory problem.

Follow-up prior lead: selected Theorem1 common-component and polyhedron passages of Makur–Singh2309.08475v2 were read after the public note froze. The classical bound follows directly from the usual common-component formula: fix P1, bound sum_y(P1(y)-min_i Pi(y)) by sum_(i=2)^d sum_y(P1(y)-Pi(y))_+, and then by(d-1)*eta_TV. This is an elementary consequence of prior definitions, not a claimed new classical result. Literal identical theorem wording has not been located; do not infer worldwide priority from that.

