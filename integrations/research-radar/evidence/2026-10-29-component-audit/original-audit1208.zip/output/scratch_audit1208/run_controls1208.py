from pathlib import Path
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone

scratch = Path(__file__).resolve().parent
out = scratch.parent
inp = out.parent / 'input'
expected_manifest = '9cc1630ae94b9ff6a6580d463bd01e72062a78053c2b78bf4ae992f826464c12'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def verify():
    mp = inp / 'INPUT1208.json'
    result = {'manifest_sha256': digest(mp), 'manifest_expected_sha256': expected_manifest,
              'manifest_matches': digest(mp) == expected_manifest, 'files': []}
    for f in json.loads(mp.read_text(encoding='utf-8-sig'))['files']:
        p = inp / f['path']
        result['files'].append({'path': f['path'], 'sha256': digest(p),
            'expected_sha256': f['sha256'], 'hash_matches': digest(p) == f['sha256'],
            'bytes': p.stat().st_size, 'expected_bytes': f['bytes'],
            'size_matches': p.stat().st_size == f['bytes']})
    result['all_pass'] = result['manifest_matches'] and all(
        f['hash_matches'] and f['size_matches'] for f in result['files'])
    return result

report = {'started_utc': datetime.now(timezone.utc).isoformat(),
          'python': sys.version, 'python_executable': sys.executable,
          'working_directory': str(scratch), 'before': verify(), 'runs': []}
assert report['before']['all_pass']
for stem, target, file_output in [
    ('check_exact1206.py', 'EXACT1206.json', False),
    ('check_exact1207.py', 'EXACT1207.json', False),
    ('check_classical1207.py', 'CLASSICAL1207.json', True),
]:
    copied_hash = digest(scratch / stem)
    assert copied_hash == digest(inp / stem)
    p = subprocess.run([sys.executable, str(scratch / stem)], cwd=scratch,
                       capture_output=True, check=False)
    (scratch / (stem + '.stdout.txt')).write_bytes(p.stdout)
    (scratch / (stem + '.stderr.txt')).write_bytes(p.stderr)
    if not file_output:
        (scratch / target).write_bytes(p.stdout)
    record = {'checker': stem, 'copied_sha256': copied_hash, 'exit_code': p.returncode,
              'stdout_file': stem + '.stdout.txt', 'stderr_file': stem + '.stderr.txt',
              'output': target}
    try:
        actual = json.loads((scratch / target).read_text(encoding='utf-8-sig'))
        frozen = json.loads((inp / target).read_text(encoding='utf-8-sig'))
        record['parsed_json_equal'] = actual == frozen
        record['byte_equal'] = (scratch / target).read_bytes() == (inp / target).read_bytes()
        record['output_sha256'] = digest(scratch / target)
        record['frozen_sha256'] = digest(inp / target)
    except Exception as exc:
        record['comparison_exception'] = repr(exc)
        record['parsed_json_equal'] = False
    report['runs'].append(record)
report['after'] = verify()
report['all_controls_pass'] = report['after']['all_pass'] and all(
    x['exit_code'] == 0 and x['parsed_json_equal'] for x in report['runs'])
report['finished_utc'] = datetime.now(timezone.utc).isoformat()
(out / 'controls1208.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
