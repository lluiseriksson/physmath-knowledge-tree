from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

out = Path(__file__).resolve().parent.parent
inp = out.parent / 'input'

def write_json(name, data):
    (out / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

supported = 'supported within stated hypotheses'
claims = [
    ('C01', 'Dual spectral-oscillation inequality with ordinary trace coefficient r', supported,
     'Extremal pure states, centered observable Holder inequality; no factor-two error. The duality itself is prior machinery.'),
    ('C02', 'b >= max(0,1-(d-1)r) for a square d-dimensional prefix', supported,
     'Integrate the minimum-eigenvalue/trace/oscillation bound; Psi* unital suffices, Psi need not be unital.'),
    ('C03', 'Measurability and finite-dimensional integrability', supported,
     'Minimum eigenvalues are continuous; positive matrix integrands have integrable trace. No measurable eigenvector selection is needed.'),
    ('C04', 'Actual preparation posterior law and minorization', supported,
     'Summing earlier records yields Tr(Psi*(F_a)rho); final posterior tau_a is independent of the input and earlier records.'),
    ('C05', 'Uniform block-length consequence under r <= q^(L-1)', supported,
     'Choose (d-1)q^(L-1)<1; retain environmental joint measurability, null-set, and indexing hypotheses.'),
    ('C06', 'Continuous Choi-integral CP remainder', supported,
     'Unnormalized input-first J has integrand (G_a-c_a I)^T tensor tau_a; positive and trace-integrable.'),
    ('C07', 'Trace normalization and substantive b=0/b=1 endpoint conclusions', supported,
     'Partial output trace equals (1-b)I; b=0 gives Omega=0, b=1 gives zero remainder.'),
    ('C08', 'Decomposition display labelled only when b>0', 'needs correction',
     'Minor presentation repair: use 0<b<1 with defined Q; give N=R_Omega separately at b=1, or explicitly choose arbitrary Q there.'),
    ('C09', 'Equal-reference complete trace-distance upper factor 1-b', supported,
     'Common replacer term cancels; Q tensor id is CPTP for every finite reference dimension.'),
    ('C10', 'Equal-reference complete Umegaki upper factor 1-b', supported,
     'Joint convexity and data processing; ratios require positive finite denominator; treat b=1 separately from 0 times infinity.'),
    ('C11', 'Planar continuum and rational four-point calibration', supported,
     'Circle second moments establish the continuum formula; finite exact checks reproduce b=1/2 with consistent density normalizations.'),
    ('C12', 'Positive CP common-component optimum 1/2 for the planar squared channel', supported,
     'Positive primal Omega and positive dual with Tr_input Z=I have equal objective 1/2; no SDP solver required.'),
    ('C13', 'Original EXACT1206 direct verification coverage', 'needs correction',
     'Original closure checks alone do not assert uniform invariant branch weights, and its iterate loop constructs closed forms. Supplement verifies weights and recursive channel application. The mathematical conclusions remain supported.'),
    ('C14', 'Classical exclusion-mixture family including its quantum ordinary trace coefficient', supported,
     'On trace-zero Hermitian inputs Psi_s=-s/(d-1) times dephasing; basis-state pairs attain the norm. alpha_+=1-s.'),
    ('C15', 'Exact positive common-component envelope under eta_tr(Psi)<=r', supported,
     'Minimum equals max(0,1-(d-1)r), attained using d classical outputs. The plateau uses <=r, not equality.'),
    ('C16', 'Pauli and deterministic-depolarizing adverse controls', supported,
     'They separate summed channels from recorded posterior kernels and trace/W1 convergence from posterior TV convergence.'),
    ('C17', 'Novelty or priority of the combined dimension/envelope result', 'not established',
     'Selected primary passages and bounded searches do not establish worldwide novelty; several building blocks are explicitly prior.'),
    ('C18', 'Sharp complete trace/Umegaki coefficients from the common-component envelope', 'not established',
     'No lower bound on these complete coefficients is supplied by tightness of alpha_+.'),
    ('C19', 'Sharpness with a fixed output dimension below d', 'not established',
     'The attaining classical construction uses d distinguishable outputs.'),
    ('C20', 'Capacity or full quenched limit-theorem consequences', 'not established',
     'Outside the supplied component and not proved by this audit.'),
    ('C21', 'Existing neighboring source direction flag as a paper-level refutation', 'not established',
     'Preserved as unresolved. The neighboring proof/PDF and the unspecified earlier diagnostic were not adjudicated.'),
]

adverse = [
    {'extension': 'The same posterior minorization for arbitrary recorded unravelings',
     'status': 'refuted', 'asserted_by_packet': False,
     'falsifier': 'd=2 four-Pauli recorded instrument: summed channel is replacement; delta_(I/2) and the uniform law on the two basis pure states are disjoint invariant laws.'},
    {'extension': 'Remove equal reference marginals from complete trace/Umegaki contraction',
     'status': 'refuted', 'asserted_by_packet': False,
     'falsifier': 'A replacer on A preserves all distance between product inputs differing only in a qubit R marginal.'},
    {'extension': 'Representation mass b always equals the optimized channel or posterior common coefficient',
     'status': 'refuted', 'asserted_by_packet': False,
     'falsifier': 'd=2, identity prefix, projective measurement, both labels prepare the same tau: b=0 but alpha_+=1 and posterior law delta_tau.'},
    {'extension': 'Trace/W1 convergence implies posterior-law TV convergence',
     'status': 'refuted', 'asserted_by_packet': False,
     'falsifier': 'The single-record depolarizing map yields distinct point masses at every finite L: TV=1 but trace/W1=2^(-L).'},
    {'extension': 'The dimension CP component belongs to Psi without EB postprocessing',
     'status': 'refuted', 'asserted_by_packet': False,
     'falsifier': 'd=2, Phi(X)=(Tr(X)I+X^T)/3: eta_tr=1/3 but alpha_+=0 from symmetric Choi support. Identity postprocessing is not EB.'},
]

source_data = [
    {'id': 'S1', 'authors': 'Hafouta–Pathirana', 'version': '2609.40096v1',
     'url': 'https://arxiv.org/html/2609.40096v1',
     'read': 'Selected Appendix A.2: Proposition A.2, finite/general-outcome criterion and proof; finite-preparation bound.',
     'not_read_or_not_audited': 'Main limit-theorem proofs; full environmental machinery.',
     'use': 'Prior general-outcome posterior criterion and finite-label contraction sufficient condition.'},
    {'id': 'S2', 'authors': 'George–Hirche–Nuradha–Wilde', 'version': '2503.22823v3',
     'url': 'https://arxiv.org/html/2503.22823v3#S7.SS2',
     'read': 'Proposition 35 and Corollary 11 statements and proofs.',
     'not_read_or_not_audited': 'Full paper; neighboring Proposition 36 proof/PDF direction issue; earlier unspecified Theorem 5 diagnostic.',
     'use': 'Prior finite measurement-channel eigenvalue formula and equality of variants for measurement outputs.'},
    {'id': 'S3', 'authors': 'Hirche', 'version': '2405.00105v2',
     'url': 'https://arxiv.org/html/2405.00105v2#S3',
     'read': 'Choi conventions, Lemma III.2, Proposition III.3 and Corollary III.4, with selected proofs.',
     'not_read_or_not_audited': 'Remaining full paper and all historical dependencies.',
     'use': 'Prior CP-replacer decomposition, ordinary contraction consequence, positive Choi SDP; normalize and swap factors when translating.'},
    {'id': 'S4', 'authors': 'Makur–Singh', 'version': '2309.08475v2',
     'url': 'https://arxiv.org/html/2309.08475v2#S2.SS1',
     'read': 'Definition 1, relevant Theorem 1 properties, normalization/polyhedron proof portions.',
     'not_read_or_not_audited': 'Remaining proofs and applications; exact prior occurrence of the dimension-envelope formula.',
     'use': 'Classical common-component formula is prior. Property 6 is an upper comparison and is not the target dimension lower comparison.'},
    {'id': 'S5', 'authors': 'Gaubert–Qu', 'version': 'Author-hosted paper',
     'url': 'https://www.cmap.polytechnique.fr/~gaubert/PAPERS/GaubertQuIEOTD14QuFinal.pdf',
     'read': 'Theorem 1.1 statement; Section 7 norm definitions, Corollary 7.1 and its local proof.',
     'not_read_or_not_audited': 'Complete general-cone theory and earlier dependency proofs.',
     'use': 'Spectral-oscillation/trace-contraction duality is prior.'},
    {'id': 'S6', 'authors': 'Pathirana', 'version': '2605.00157v1',
     'url': 'https://arxiv.org/html/2605.00157v1',
     'read': 'Selected Section 2.1 and Appendix A CP-order comparison, especially Example 4.',
     'not_read_or_not_audited': 'Full channel-product/MPS results.',
     'use': 'State-level versus CP-order distinction; symmetric-support falsifier to dropping EB postprocessing.'},
    {'id': 'S7', 'authors': 'Lee–Lu–Makur–Singh', 'version': '2606.19859v1',
     'url': 'https://arxiv.org/html/2606.19859v1',
     'read': 'Introductory general-kernel common-component definitions, equations (8)-(12).',
     'not_read_or_not_audited': 'Doeblin-curve theorems, their proofs, and possible implications for this envelope.',
     'use': 'Further prior-art lead only; no novelty verdict.'},
]

sources = {
    'retrieval': 'Selected passages read using web tools; primary sources used for substantive claims.',
    'source_response_transport_hashes_reproduced': False,
    'stored_foreign_full_text': False,
    'read_sources': source_data,
    'search_queries': [
        '"Doeblin" "Dobrushin" "n-1"',
        '"quantum" "Doeblin" "dimension" contraction measurement',
        '"Doeblin coefficient" "lower bound" "Dobrushin"',
        '"quantum" "oscillation" "trace distance" contraction coefficient',
        '"Asymptotic Replacement for Quantum Channel Products" arxiv',
        '"Dobrushin" "oscillation" "Gaubert" quantum',
        '"Doeblin" "1-(d-1)"',
        '"Doeblin" "1 - (n - 1)"',
    ],
    'search_only_leads': [
        {'title': 'On Properties of Doeblin Coefficients',
         'url': 'https://japneet644.github.io/files/DoeblinCoef.pdf',
         'status': 'Search snippet only; not used as an independently read proof.'},
        {'title': 'Computational aspects of the trace norm contraction coefficient',
         'url': 'https://www.researchgate.net/publication/393923013_Computational_aspects_of_the_trace_norm_contraction_coefficient',
         'status': 'Search snippet only; not used as a proof source.'},
        {'title': 'AIRR manuscript metadata result',
         'status': 'Incidental search result; manuscript not opened or assessed.'},
    ],
    'unresolved': [
        'Exact historical priority or worldwide novelty of the combined dimension envelope.',
        'Neighboring Proposition 36 HTML direction flag from READINGS1207; no PDF/proof adjudication.',
        'Prior unspecified Theorem 5 diagnostic lacks supplied details; not treated as cleared.',
    ],
}
write_json('sources1208_audit.json', sources)

controls = json.loads((out / 'controls1208.json').read_text())
supplement = json.loads((out / 'supplement1208.json').read_text())
verdict = {
    'audit_id': '1208',
    'scope': 'One mathematical component audit of the frozen supplied proofs and exact controls; no manuscript/PDF assessment.',
    'completed_utc': datetime.now(timezone.utc).isoformat(),
    'requested_configuration': {'model': 'gpt-6-astra', 'reasoning_effort': 'xhigh'},
    'effective_configuration': {'model': 'unknown', 'reasoning_effort': 'unknown', 'attestation': 'unattested'},
    'context': {'fork_turns_none': 'requested, not independently attested',
                'filesystem': 'shared', 'runtime_isolation': 'unverified',
                'statistical_independence': 'unverified', 'human_peer_review': False},
    'unscored': True,
    'overall_mathematical_verdict': supported,
    'summary': 'The dimension minorization, continuous CP remainder, equal-reference trace/Umegaki upper factors, and sufficiently-large-output positive common-component envelope are valid under the stated hypotheses. Only minor endpoint notation and original-checker coverage wording need repair.',
    'novelty_verdict': 'not established',
    'envelope': {'quantity': 'inf alpha_+(E o Psi) with square d-dimensional Psi, eta_tr(Psi)<=r, and admissible finite-dimensional EB E',
                 'formula': 'max(0,1-(d-1)*r)', 'd': 'd>=2; d=1 separately equals 1',
                 'r': '0<=r<=1 naturally; r>1 repeats the zero plateau',
                 'output_requirement': 'd orthogonal output states allowed',
                 'attainment': 'minimum attained by the classical exclusion-mixture family',
                 'sharp_complete_contraction_claim': False},
    'claims': [{'id': i, 'claim': c, 'status': s, 'reason': r} for i,c,s,r in claims],
    'scope_extension_falsifiers': adverse,
    'controls': {'all_supplied_exit_codes_zero': all(x['exit_code']==0 for x in controls['runs']),
                 'all_supplied_semantic_json_matches': all(x['parsed_json_equal'] for x in controls['runs']),
                 'exact1206_raw_byte_equality': False,
                 'exact1206_mismatch_explanation': supplement['exact1206_byte_mismatch'],
                 'supplemental_invariant_weights_and_recursive_iterates': 'passed',
                 'all_frozen_hashes_match': controls['before']['all_pass'] and controls['after']['all_pass'],
                 'finite_checks_are_general_theorem_certificates': False},
    'preserved_failures_and_inconclusives': [
        'EXACT1206 raw bytes differ only by 144 LF-to-CRLF conversions; raw logs retained.',
        'Original checker coverage was weaker than its invariant-law/iteration labels; supplemental checks passed without modifying originals.',
        'Real calibration does not test complex transposition; general analytic identity and a complex qubit diagnostic cover the issue.',
        'Historical HTTP response hashes recorded in readings were not reproduced.',
        'Effective model, effort, runtime isolation and statistical independence are unattested.',
        'Novelty, sharp complete coefficients, smaller-output sharpness, capacities and full limit theorems remain unestablished.',
        'Neighboring source direction flag and unspecified earlier diagnostic remain unresolved; no source-paper refutation.',
    ],
    'exclusions': ['future binary-symmetric-channel sketch', 'manuscript assessment', 'grade or vote',
                   'publication recommendation', 'new model review', 'full source-paper audit'],
    'artifacts': ['AUDIT1208.txt','verdict1208.json','controls1208.json','supplement1208.json',
                  'sources1208_audit.json','MANIFEST1208.sha256.json','scratch_audit1208/'],
    'archive': 'Parent to archive outputs to D:; no archival mutation performed by this agent.',
}
write_json('verdict1208.json', verdict)

input_manifest = json.loads((inp / 'INPUT1208.json').read_text(encoding='utf-8-sig'))
expected_manifest = '9cc1630ae94b9ff6a6580d463bd01e72062a78053c2b78bf4ae992f826464c12'
input_files = [{'path': 'INPUT1208.json', 'sha256': h(inp/'INPUT1208.json'),
                'expected_sha256': expected_manifest,
                'matches': h(inp/'INPUT1208.json')==expected_manifest,
                'bytes': (inp/'INPUT1208.json').stat().st_size}]
for f in input_manifest['files']:
    p = inp/f['path']
    input_files.append({'path': f['path'], 'sha256': h(p), 'expected_sha256': f['sha256'],
                        'matches': h(p)==f['sha256'] and p.stat().st_size==f['bytes'],
                        'bytes': p.stat().st_size, 'expected_bytes': f['bytes']})
allowed_statuses = {supported, 'needs correction', 'refuted', 'not established'}
assert all(x['status'] in allowed_statuses for x in verdict['claims'])
assert all(x['matches'] for x in input_files)
assert controls['all_controls_pass']
assert supplement['exact1206_byte_mismatch']['after_newline_normalization_equal']
assert all((out/f).exists() for f in verdict['artifacts'] if f != 'MANIFEST1208.sha256.json')

manifest_name = 'MANIFEST1208.sha256.json'
output_files = [{'path': p.relative_to(out).as_posix(), 'bytes': p.stat().st_size, 'sha256': h(p)}
                for p in sorted(out.rglob('*')) if p.is_file() and p.name != manifest_name]
manifest = {'audit_id': '1208', 'created_utc': datetime.now(timezone.utc).isoformat(),
            'algorithm': 'SHA256', 'input_root': str(inp), 'output_root': str(out),
            'frozen_inputs_final_verification': input_files,
            'all_frozen_inputs_match': all(x['matches'] for x in input_files),
            'output_files': output_files,
            'self_hash_policy': 'This manifest excludes itself. Its SHA256 is returned separately in the delivery message.'}
write_json(manifest_name, manifest)
print(json.dumps({'all_frozen_inputs_match': True, 'claims': len(claims),
                  'output_files_hashed_excluding_manifest': len(output_files),
                  'AUDIT1208.txt_sha256': h(out/'AUDIT1208.txt'),
                  'verdict1208.json_sha256': h(out/'verdict1208.json'),
                  'manifest_sha256': h(out/manifest_name)}, indent=2))
