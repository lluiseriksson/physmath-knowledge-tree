from pathlib import Path
from fractions import Fraction as Q
import contextlib
import io
import json
import runpy

root = Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    m = runpy.run_path(str(root / 'check_exact1206.py'))
pure0, pure1, mixed = m['pure0'], m['pure1'], m['mixed']
mul, trans, add, scale = (m[k] for k in ('mul', 'trans', 'add', 'scale'))
counts = []
for state in (pure0, pure1):
    images = [mul(mul(u, state), trans(u)) for u in m['us']]
    counts.append([images.count(pure0), images.count(pure1)])
assert counts == [[2, 2], [2, 2]]

def depolarize(a):
    return add(scale(Q(1, 2), a), scale(m['tr'](a) / 4, m['I']))

a, b = pure0, pure1
for L in range(1, 21):
    a, b = depolarize(a), depolarize(b)
    factor = Q(1, 2) ** L
    assert a == scale(Q(1, 2), add(m['I'], scale(factor, m['Z'])))
    assert b == scale(Q(1, 2), add(m['I'], scale(-factor, m['Z'])))
    assert a != b

frozen = root.parent.parent / 'input' / 'EXACT1206.json'
raw_frozen = frozen.read_bytes()
raw_rerun = (root / 'EXACT1206.json').read_bytes()
report = {
    'scope': 'Supplement supplied finite controls; not a general theorem certificate',
    'invariant_uniform_pure_law_branch_counts_from_both_pure_states': counts,
    'invariant_law_probabilities_each': '1/2',
    'actual_recursive_depolarizing_application_matches_closed_form_all_20': True,
    'exact1206_byte_mismatch': {
        'frozen_bytes': len(raw_frozen), 'rerun_bytes': len(raw_rerun),
        'frozen_crlf': raw_frozen.count(b'\r\n'),
        'rerun_crlf': raw_rerun.count(b'\r\n'),
        'after_newline_normalization_equal': raw_frozen.replace(b'\r\n', b'\n') == raw_rerun.replace(b'\r\n', b'\n'),
    },
    'arithmetic': 'fractions.Fraction',
}
(root.parent / 'supplement1208.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
