from pathlib import Path
from fractions import Fraction
import argparse,hashlib,json,sys,time,types,platform,datetime,subprocess
ROOT=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix(path.suffix+'.tmp')
 tmp.write_bytes((json.dumps(obj,indent=2)+'\n').encode())
 tmp.replace(path)
def load(anchor):
 raw=(ROOT/'INPUT1334.json').read_bytes()
 if sha(raw)!=anchor:raise ValueError('Manifest trust anchor mismatch before numerical import')
 manifest=json.loads(raw);buffers={};bindings=[]
 for name,h in manifest['files'].items():
  path=(ROOT/name).resolve()
  if not path.is_relative_to(ROOT):raise ValueError('Input escapes package')
  b=path.read_bytes()
  if sha(b)!=h:raise ValueError('Input hash mismatch: '+name)
  buffers[name]=b;bindings.append({'path':name,'sha256':h,'verified_buffer':True})
 return manifest,buffers,bindings
def engine_env(buffers,out):
 import flint
 from flint import arb,acb,fmpq,ctx
 if flint.__version__!='0.9.0':raise ValueError('Unexpected python-flint version')
 engine=types.ModuleType('bound_interval1334');engine.__file__=str(ROOT/'inputs/interval778.py')
 exec(compile(buffers['inputs/interval778.py'],engine.__file__,'exec'),engine.__dict__)
 ctx.prec=256;engine.T=600
 candidate=json.loads(buffers['inputs/FIT794.json'])['rows'][0]
 if not (candidate['a']==1 and candidate['N']==32 and candidate['fmax']==4 and candidate['rcond']==1e-14):raise ValueError('Unexpected fixed candidate')
 source=buffers['inputs/SOURCE795.py'].decode()
 region=source[source.index('def A(x):'):source.index('for j in range(160):segment')]
 env={'Fraction':Fraction,'arb':arb,'acb':acb,'fmpq':fmpq,'ctx':ctx,'eng':engine,'C':out,'candidate':candidate,'json':json,'time':time,'start':time.monotonic()}
 exec(compile(region,'<verified SOURCE795 mathematical function region>','exec'),env)
 return env,sha(region.encode())
def scalars(env,buffers):
 arb=env['arb'];a=env['a'];b2=env['b2'];coef=env['coef'];freq=env['freq'];eps=env['eps']
 tail=(sum((abs(d) for d in coef),arb(0))*(-env['alpha']*400).exp()+env['BH'](arb(400)))/401
 M=sum(((1+a)*(f*f*(1+a)/(4*b2)).exp()*abs(d) for d,f in zip(coef,freq)),arb(0))
 prior=json.loads(buffers['inputs/CERTIFICATE779.json'])
 assert tail.is_finite() and tail<eps and M<arb('1.5e20')
 assert all(arb(row['G1'])<arb('0.178254') for row in prior['rows'])
 assert (1+b2).log()>arb('0.178263333')
 d0=arb('0.178263333')-arb('0.178254')-4*eps
 lower=2*d0*d0/((arb('1.5e20')**2+2*d0).sqrt()+arb('1.5e20'))**2
 assert d0>0 and lower>arb('6e-52')
 return {'tail400':tail.str(45),'observable_M':M.str(45),'d0':d0.str(45),'stable_gap_expression':lower.str(45),'scalar_gap_exceeds_6e_minus52':True,'conditional_on_analytic_contract798':True}
def runtime():
 import flint
 from flint import arb
 files=[Path(sys.executable),Path(flint.__file__),Path(sys.modules[arb.__module__].__file__)]
 return {'python':sys.version,'flint':flint.__version__,'platform':platform.platform(),'files':[{'name':p.name,'sha256':sha(p.read_bytes())} for p in files]}
def unchanged(manifest):return all(sha((ROOT/n).read_bytes())==h for n,h in manifest['files'].items())
def worker(args,manifest,buffers,bindings):
 plan=json.loads(buffers['PLAN1334.json'])['segments'];out=ROOT/'outputs'/f'worker{args.worker}';out.mkdir(parents=True,exist_ok=False)
 env,region=engine_env(buffers,out)
 chosen=[s for s in plan if s['id']%args.workers==args.worker]
 for s in chosen:env['segment'](Fraction(s['left']),Fraction(s['width']),s['n'],s['H_interpolated'])
 assert unchanged(manifest)
 result={'worker':args.worker,'worker_count':args.workers,'input_manifest_sha256':args.manifest_sha256,'runner_sha256':sha(Path(__file__).read_bytes()),'function_region_sha256':region,
 'bindings':bindings,'post_inputs_unchanged':True,'precision_bits':env['ctx'].prec,'T':env['eng'].T,'runtime':runtime(),
 'segments':[dict(row,segment_id=s['id']) for row,s in zip(env['rows'],chosen)],'scalar_checks':scalars(env,buffers)}
 assert len(result['segments'])==len(chosen) and all(x['proved_below_eps'] for x in result['segments'])
 write(out/'RUN1334.json',result)
def parent(args,manifest,buffers,bindings):
 out=ROOT/'outputs';out.mkdir(exist_ok=False)
 guard=subprocess.run([sys.executable,str(Path(__file__)),'--manifest-sha256','0'*64,'--preflight'],capture_output=True,text=True)
 guard_ok=guard.returncode==2 and 'Manifest trust anchor mismatch' in guard.stderr
 write(out/'GUARD1334.json',{'expected_failure':True,'expected_exit':2,'exit_code':guard.returncode,'stdout':guard.stdout,'stderr':guard.stderr,'numerical_workers_not_started':True,'passed':guard_ok})
 assert guard_ok
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();procs=[];handles=[]
 try:
  for k in range(args.workers):
   log=(out/f'worker{k}.log').open('wb');handles.append(log)
   procs.append(subprocess.Popen([sys.executable,str(Path(__file__)),'--manifest-sha256',args.manifest_sha256,'--worker',str(k),'--workers',str(args.workers)],stdout=log,stderr=subprocess.STDOUT))
  deadline=time.monotonic()+900
  while any(p.poll() is None for p in procs):
   if time.monotonic()>deadline:raise TimeoutError('Fixed full-run900second deadline reached; no retry')
   if any(p.poll() not in (None,0) for p in procs):raise RuntimeError('A worker failed; no retry')
   time.sleep(0.2)
  assert all(p.returncode==0 for p in procs)
 finally:
  for p in procs:
   if p.poll() is None:p.terminate()
  for p in procs:
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  for h in handles:h.close()
 results=[];rows=[];worker_artifacts=[]
 for k in range(args.workers):
  path=out/f'worker{k}'/'RUN1334.json';raw=path.read_bytes();r=json.loads(raw)
  assert r['worker']==k and r['worker_count']==args.workers and r['input_manifest_sha256']==args.manifest_sha256
  assert r['runner_sha256']==manifest['files']['full1334.py'] and r['post_inputs_unchanged'] and r['precision_bits']==256 and r['T']==600
  assert r['bindings']==bindings
  results.append(r);rows.extend(r['segments']);worker_artifacts.append({'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(raw),'bytes':len(raw)})
 rows.sort(key=lambda x:x['segment_id']);plan=json.loads(buffers['PLAN1334.json'])['segments']
 assert len(rows)==len(plan)==320 and [r['segment_id'] for r in rows]==list(range(320))
 for r,s in zip(rows,plan):
  assert (r['left'],r['width'],r['n'],r['H_interpolated'])==(s['left'],s['width'],s['n'],s['H_interpolated'])
 for i in range(319):assert Fraction(plan[i]['left'])+Fraction(plan[i]['width'])==Fraction(plan[i+1]['left'])
 assert Fraction(plan[0]['left'])==0 and Fraction(plan[-1]['left'])+Fraction(plan[-1]['width'])==400
 env,region=engine_env(buffers,out/'aggregation')
 for r in rows:
  b=env['arb'](r['bound']);assert b.is_finite() and b<env['eps'] and r['proved_below_eps']
 assert all(r['function_region_sha256']==region for r in results) and unchanged(manifest)
 scalar=scalars(env,buffers)
 full={'status':'All320 fixed segments pass with manifest-bound mathematical buffers and worker records; trusted ball arithmetic, not formal proof',
 'started_at':started,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':args.manifest_sha256,'runner_sha256':manifest['files']['full1334.py'],
 'function_region_sha256':region,'binding_at_load':bindings,'post_inputs_unchanged':True,'workers':worker_artifacts,'worker_count':args.workers,'segment_count':320,
 'coverage':[0,400],'precision_bits':256,'T':600,'epsilon':'1e-6','all_bounds_below_eps':True,'segments':rows,'scalars':scalar,'runtime':runtime(),
 'limits':['O4 trusted Arb/analytic reasoning remains','No retrospective attestation of795','No new manuscript, model review or grade','Research Capsule readiness must be separately verified','Not a practical energy/blocklength claim']}
 write(ROOT/'FULL1334.json',full)
 print(json.dumps({'status':'PASS','segments':320,'workers':args.workers,'scalar_gap_exceeds_6e_minus52':True}),flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest-sha256',required=True);p.add_argument('--preflight',action='store_true');p.add_argument('--worker',type=int);p.add_argument('--workers',type=int,default=8)
 args=p.parse_args();manifest,buffers,bindings=load(args.manifest_sha256)
 if args.preflight:print('PREFLIGHT_PASS');return
 if args.workers!=8:raise ValueError('Unexpected fixed worker count')
 if args.worker is not None:
  if args.worker not in range(8):raise ValueError('Unexpected worker id')
  worker(args,manifest,buffers,bindings)
 else:parent(args,manifest,buffers,bindings)
if __name__=='__main__':
 try:main()
 except Exception as e:print(type(e).__name__+': '+str(e),file=sys.stderr);raise SystemExit(2)
