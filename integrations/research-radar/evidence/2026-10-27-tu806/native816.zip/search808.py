from pathlib import Path
from collections import Counter
from fractions import Fraction
import itertools,random,math,json,time,hashlib,sys
import numpy as np,scipy,sympy as sp
from scipy.optimize import linprog
C=Path(__file__).parent;rng=random.Random(808);started=time.monotonic();results=[];all_leads=[]
for graph in ['K5','K33']:
 n=5 if graph=='K5' else 6
 edges=list(itertools.combinations(range(n),2)) if graph=='K5' else [(i,j) for i in range(3) for j in range(3,6)]
 # Exact spanning-tree basis, then the regular-matroid dual [-N^T|I].
 tree=[];seen={0}
 while len(seen)<n:
  for j,(u,v) in enumerate(edges):
   if (u in seen) != (v in seen):tree.append(j);seen|={u,v};break
 M=sp.Matrix([[int(i==u)-int(i==v) for u,v in edges] for i in range(n-1)]);T=M[:,tree];assert abs(T.det())==1
 chords=[j for j in range(len(edges)) if j not in tree];N=T.inv()*M[:,chords]
 assert all(v.q==1 for v in N)
 A=(-N.T).row_join(sp.eye(len(chords)));cols=[tuple(int(A[i,j]) for i in range(A.rows)) for j in range(A.cols)]
 # Existing code uses n-1 as the number of independent coordinates.
 n=A.rows+1
 for trial in range(24):
  weights=[1]*len(edges) if trial==0 else [rng.choice([1,2,3,7,31,127]) for _ in edges]
  counts=Counter({(0,)*(n-1):1})
  for col,w in zip(cols,weights):
   newer=counts.copy()
   for b,v in counts.items():newer[tuple(x+y for x,y in zip(b,col))]+=v*w
   counts=newer
  assert sum(counts.values())==math.prod(1+w for w in weights)
  pts=sorted(counts);eq=np.vstack([np.ones(len(pts)),np.array(pts,dtype=float).T]);objective=-np.array([math.log(counts[b]) for b in pts]);targets=[b for b in pts if counts[b]>1];rng.shuffle(targets);probes=[]
  for b in targets[:100]:
   lp=linprog(objective,A_eq=eq,b_eq=[1,*b],bounds=(0,None),method='highs');rec={'b':b,'count':counts[b],'lp_status':int(lp.status)}
   if not lp.success:rec['failure']=lp.message;probes.append(rec);continue
   gap=float(-lp.fun-math.log(counts[b]));rec['log_gap_FLOAT_ONLY']=gap
   if gap>1e-7:
    inds=[i for i,v in enumerate(lp.x) if v>1e-10];mat=sp.Matrix([[1]*len(inds)]+[[pts[j][i] for j in inds] for i in range(n-1)]);ws=list(sp.linsolve((mat,sp.Matrix([1,*b]))));lead={'n':n,'trial':trial,'b':b,'weights':weights,'float_gap':gap,'numeric_support':[(pts[i],float(lp.x[i])) for i in inds]}
    if len(ws)==1 and all(not x.free_symbols and x>0 for x in ws[0]):
     ws=ws[0];den=int(sp.ilcm(*[x.q for x in ws]));lhs=counts[b]**den;rhs=math.prod(counts[pts[j]]**int(den*x) for x,j in zip(ws,inds));lead.update(exact_denominator=den,exact_weights=[str(x) for x in ws],exact_lhs=str(lhs),exact_rhs=str(rhs),exact_violation=rhs>lhs);rec['exact_violation']=rhs>lhs
    else:lead['exact_reconstruction']='inconclusive; lead retained, not a certificate'
    all_leads.append(lead)
   probes.append(rec)
   if rec.get('exact_violation'):break
  row={'vertices':n,'edges':edges,'matrix':cols,'family':'cographic','trial':trial,'weights':weights,'fiber_count':len(pts),'binary_configurations':2**len(edges),'counts_checksum_total':sum(counts.values()),'counts':[(b,counts[b]) for b in pts],'probes':probes};results.append(row)
  record={'status':'bounded exact counts plus FLOAT LP leads only; no global Jensen proof','seed':808,'results':results,'leads':all_leads,'seconds':time.monotonic()-started,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__},'matrix_proof':'Dual columns form [-N^T|I] from a spanning-tree normalized graph-incidence [I|N], hence TU. Weighted binary lift398 fixes one selected column per edge, so all lifted nonnegative integer fibers are finite.','not_claimed':['exhaustive TU search','Jensen proof','new paper or score','independent review','Research Capsule readiness']}
  (C/'SEARCH808.json').write_bytes((json.dumps(record,separators=(',',':'))+'\n').encode());print(json.dumps({'n':n,'trial':trial,'fibers':len(pts),'LPs':len(probes),'max_float_gap':max([x.get('log_gap_FLOAT_ONLY',-1) for x in probes]),'leads':len(all_leads),'seconds':time.monotonic()-started}),flush=True)
  if any(x.get('exact_violation') for x in all_leads):raise SystemExit(0)
