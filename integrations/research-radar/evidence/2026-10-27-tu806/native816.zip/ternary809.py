from pathlib import Path
from collections import Counter,defaultdict
import itertools,json,time,hashlib
C=Path(__file__).parent;start=time.monotonic();n=4;edges=list(itertools.combinations(range(n),2));cols=[tuple(int(i==u)-int(i==v) for i in range(n-1)) for u,v in edges];fib=defaultdict(list)
for x in itertools.product([0,1],repeat=len(edges)):
 b=tuple(sum(x[j]*cols[j][i] for j in range(len(edges))) for i in range(n-1));fib[b].append(sum(x[j]*4**j for j in range(len(edges))))
central={b:Counter(x+y+z for x in ff for y in ff for z in ff) for b,ff in fib.items()};tested=0;witness=None
for triple in itertools.combinations_with_replacement(sorted(fib),3):
 sums=tuple(sum(t[i] for t in triple) for i in range(n-1))
 if any(v%3 for v in sums) or len(set(triple))==1:continue
 b=tuple(v//3 for v in sums)
 if b not in fib:continue
 other=Counter(x+y+z for x in fib[triple[0]] for y in fib[triple[1]] for z in fib[triple[2]]);tested+=1
 for S,count in other.items():
  if count>central[b][S]:witness={'center':b,'rhs_triple':triple,'exponents':[(S//4**j)%4 for j in range(len(edges))],'other_coefficient':count,'central_coefficient':central[b][S],'center_fiber_bits':[[int(S//4**j)%4 for j in range(len(edges))] for S in fib[b]],'endpoint_fiber_bits':[[[int(S//4**j)%4 for j in range(len(edges))] for S in fib[t]] for t in triple]};break
 if witness:break
out={'target':'Coefficientwise ternary extension of the source midpoint mechanism, NOT Jensen itself','graph':'K4','edges':edges,'matrix_columns':cols,'binary_configurations':64,'fibers':len(fib),'rhs_triples_tested':tested,'exact_negative_coefficient_witness':witness,'Jensen_counterexample':False,'seconds':time.monotonic()-start,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(C/'TERNARY809.json').write_bytes((json.dumps(out,indent=2)+'\n').encode());print(json.dumps(out,indent=2))
