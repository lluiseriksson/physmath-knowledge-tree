from flint import acb,arb,ctx
import time,json
ctx.prec=128
def integrand(t,analytic,z):
 if analytic and not abs(t.imag)<arb(1)/4:return acb('nan')
 B=(2*z*t).hypgeom_0f1(1)
 one=(1+(t-z).exp()/2).log(analytic=analytic)
 two=(1+2*(z-t).exp()).log(analytic=analytic)
 return B*((-2*t-z).exp()*one+(-t-2*z).exp()*two/2)
def H(z):
 z=acb(z)
 return acb.integral(lambda t,a:integrand(t,a,z),0,200,abs_tol=arb('1e-11'),rel_tol=arb('1e-10'),eval_limit=20000,depth_limit=30)
rows=[]
for z in [0,1,4,6]:
 start=time.monotonic();v=H(z);row={'z':z,'H_truncated':str(v),'seconds':time.monotonic()-start};rows.append(row);print(json.dumps(row),flush=True)
