# Research Dossier: Bounded raw-contour SU2 falsifier

- **Workspace:** `workspace.raw-unit1415`
- **Generated:** 2026-10-30T16:40:56.461Z
- **Graph:** PhysMath Knowledge Tree 2.6.0
- **Content fingerprint:** `d405afefd1eae8842d6f15528363e8b280cf12f4c262baf1be3fe87adc89f4ec`
- **Readiness:** **attention**

## Readiness gates

| Gate | State | Progress | Detail |
| --- | --- | ---: | --- |
| Scope | ready | 1/1 | 1 canonical nodes selected. |
| Mechanism | ready | 1/1 | Working notes or a bridge-card draft document the intended mechanism. |
| Falsifiability | ready | 1/1 | A falsifier or next discriminating test is recorded. |
| Evidence | attention | 0/4 | 4 source-bearing references still need verification. |
| Lean names | attention | 0/1 | 1 import/declaration candidates remain unaudited. |
| Canonical changes | not-applicable | 0/0 | No local canonical-change baseline is available. |

## Canonical scope

- Nodes: 1
- Induced edges: 0

- **Uniform one-step Yang-Mills RG activity bound** (`problem.uniform_yang_mills_rg_activity`) — Define the local activity produced by the actual gauge-fixed one-step renormalization integral and prove support, coupling-power and modified-metric decay estimates with constants uniform in volume, cutoff, scale, background and admissible hole geometry.

## Evidence

- References in scope: 4
- Source-bearing references: 4
- Locally reviewed: 0

- [unreviewed] A. Jaffe and E. Witten — Quantum Yang-Mills Theory — https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf
- [unreviewed] J. Dimock — The Renormalization Group According to Balaban I — https://arxiv.org/abs/1108.1335
- [unreviewed] J. Dimock — The Renormalization Group According to Balaban II — https://arxiv.org/abs/1212.5562
- [unreviewed] J. Dimock — The Renormalization Group According to Balaban III — https://arxiv.org/abs/1304.0705

## Lean target audit

- Items in scope: 3
- Imports/declarations: 1
- Locally reviewed: 0

- [unreviewed] Uniform one-step Yang-Mills RG activity bound · import: `Mathlib`
- [unreviewed] Uniform one-step Yang-Mills RG activity bound · target: `Define the one-step gauge fluctuation identity and concrete raw activity before stating its decay.`
- [unreviewed] Uniform one-step Yang-Mills RG activity bound · target: `Separate block coercivity, background-Hessian stability, covariance decay, collar localization and local R-operation gain into auditable inputs.`

## Canonical change governance

- No local change-review baseline was available.


## Open actions

- **attention · evidence:** Review a source-bearing reference — J. Dimock — The Renormalization Group According to Balaban I
- **attention · evidence:** Review a source-bearing reference — J. Dimock — The Renormalization Group According to Balaban II
- **attention · evidence:** Review a source-bearing reference — J. Dimock — The Renormalization Group According to Balaban III
- **attention · evidence:** Review a source-bearing reference — A. Jaffe and E. Witten — Quantum Yang-Mills Theory
- **attention · lean:** Audit a Lean name — Uniform one-step Yang-Mills RG activity bound: Mathlib

## Workspace notes

Private finite numerical falsifier; not a physical result or independent review. Source family and complex cutoff remain open.

## Bridge-card drafts

### Raw selected coefficient falsifier

# Frozen raw-contour SU(2) falsifier

Frozen before first execution. Participating agent only; no independent assessment, score or paper. Four cases: d=2, three coarse blocks in each direction, L=2 and3; flat and noncommuting constant backgrounds, gauge-conjugated by seed1701 normalized Gaussian quaternions at every site. Nonflat links exp(i0.37 sigma_x), exp(i b sigma_z), b=a0/(16*0.37), a0=alpha/(72L^2), alpha=1/L. All18 coarse rows and54 selected Pauli directions are included, including wrapped edges. Pauli-coordinate Euclidean norm equals Hermitian traceless 2x2 operator norm.

Compute Eq42 from actual contour products and inverse links, descending-coordinate block paths. Differentiate products by the full product rule, including inverse derivatives. Use the SU2 logarithm and twelve-term dexp series; this is double precision, not interval arithmetic. Compare selected blocks with alpha Ad_prefix, the candidate9y bound, inverse bound2/alpha, and off-diagonal zero. Tolerances1e-10 for inequalities/structural zero/unitarity. Independently centered-difference wrapped selected column53 with fixed h=1e-5; error tolerance1e-8. No seed/step/case search, tolerance tuning or rerun to force passage. Preserve failed/incomplete outcomes. A failure requires diagnosis before calling it a mathematical counterexample.

Primary source: existing CMP95 path Eq1.7â€“1.8, CMP98 original average Eq42, candidate RAW-UNIT-CONSTRAINT-BUDGET1413.md and GEOMETRY-AUDIT1414.md, archived with their checkpoint hashes. Compilation SHA25600cc6b218dcf0e1c2884e135caa1d57b3591df036540b685e7440f30cbd4ff16. This test can falsify a coefficient/implementation assertion on its finite cases; a pass establishes no all-dimension theorem, complex-radius/cutoff match, actual physical source family, marked G/H bound, hRpoly, decay or continuum conclusion.

Confidence: formalâ€”none new; literatureâ€”selected source formulas; heuristicâ€”numerical falsifier; speculativeâ€”physical application remains open. Existing graph scope problem.uniform_yang_mills_rg_activity is a target, not a proved result. Bind actual dossier and run manifest to a verified Research Capsule before describing the recorded computation as reproducible. Capsule readiness describes metadata only. No canonical graph edit, public corpus copy or new repository.

## Negative and inconclusive results

_No negative or inconclusive results recorded._

> This dossier is a local research handoff. It does not promote graph confidence, certify sources, prove Lean targets or mutate canonical JSON.
