"""Frozen four-case floating-point falsifier, not a theorem or interval proof."""
from pathlib import Path
import json,sys,platform,time
import numpy as np
sys.stdout.reconfigure(encoding='utf8')
HERE=Path(__file__).resolve().parent
S=np.array([[[0,1],[1,0]],[[0,-1j],[1j,0]],[[1,0],[0,-1]]],complex)
I=np.eye(2,dtype=complex)
def ex(v):
    r=np.linalg.norm(v)
    return np.cos(r)*I+1j*np.sinc(r/np.pi)*np.einsum('i,ijk->jk',v,S)
def vec(X):
    return np.array([(np.trace(s@X)/(2j)).real for s in S])
def lg(U):
    v=vec(U); n=np.linalg.norm(v)
    return v if n<1e-14 else np.arctan2(n,np.trace(U).real/2)*v/n
def ad(U):
    return np.array([[np.trace(s@U@t@U.conj().T).real/2 for t in S] for s in S])
def G(v):
    x,y,z=v; A=-2*np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
    total=np.eye(3); term=np.eye(3)
    for n in range(1,13):
        term=term@A/(n+1); total+=term
    return total
def invword(w): return [(b,-sgn) for b,sgn in w[::-1]]
def run_case(L,background):
    N=3*L; alpha=1/L; a0=alpha/(72*L*L)
    rng=np.random.default_rng(1701)
    gauges={}
    for x in np.ndindex(N,N):
        q=rng.normal(size=4); q/=np.linalg.norm(q)
        gauges[x]=q[0]*I+1j*np.einsum('i,ijk->jk',q[1:],S)
    def step(x,mu,n=1):
        z=list(x); z[mu]=(z[mu]+n)%N; return tuple(z)
    coarse=[((i*L,j*L),mu) for i,j in np.ndindex(3,3) for mu in range(2)]
    selected=[(step(y,mu,L-1),mu) for y,mu in coarse]
    selected_index={b:i for i,b in enumerate(selected)}
    base=[I,I] if background=='flat' else [ex(np.array([.37,0,0])),ex(np.array([0,0,a0/(16*.37)]))]
    links={(x,mu):gauges[x]@base[mu]@gauges[step(x,mu)].conj().T for x in np.ndindex(N,N) for mu in range(2)}
    def path(x,mu,n):
        return [( (step(x,mu,k),mu),1) for k in range(n)]
    def block(y,r):
        out=[]; x=y
        for mu in [1,0]:
            out+=path(x,mu,r[mu]); x=step(x,mu,r[mu])
        return out
    words=[]
    for y,mu in coarse:
        P=path(y,mu,L); loops=[]
        for r in np.ndindex(L,L):
            x=((y[0]+r[0])%N,(y[1]+r[1])%N)
            loops.append(block(y,r)+path(x,mu,L)+invword(block(step(y,mu,L),r))+invword(P))
        words.append((P,loops))
    def word(w,jets=True,perturb=None):
        U=I.copy(); J=np.zeros((54,2,2),complex)
        for b,sgn in w:
            F=links[b]; dF=np.zeros_like(J)
            if perturb is not None and b==selected[perturb[0]]:
                v=np.zeros(3); v[perturb[1]]=perturb[2]; F=ex(v)@F
            if jets and b in selected_index:
                k=selected_index[b]
                for j in range(3): dF[3*k+j]=1j*S[j]@F
            if sgn==-1:
                F=F.conj().T
                if jets: dF=-F@dF@F
            if jets: J=J@F+U@dF
            U=U@F
        return U,J
    def raw(P,loops,jets=True,perturb=None):
        Ys=[]; dys=[]
        for w in loops:
            H,J=word(w,jets,perturb); v=lg(H); Ys.append(v)
            if jets:
                left=J@H.conj().T
                u=np.stack([vec(a) for a in left],axis=1)
                dys.append(np.linalg.solve(G(v),u))
        Y=np.mean(Ys,axis=0); E=ex(Y); V,JV=word(P,jets,perturb)
        d=None
        if jets:
            up=np.stack([vec(a) for a in JV@V.conj().T],axis=1)
            d=G(Y)@np.mean(dys,axis=0)+ad(E)@up
        return E@V,d,max(np.linalg.norm(v) for v in Ys)
    curvature=0.; unitary=0.
    for x in np.ndindex(N,N):
        plaq=[((x,0),1),((step(x,0),1),1),((step(x,1),0),-1),((x,1),-1)]
        U,_=word(plaq,False); curvature=max(curvature,np.linalg.norm(U-I,2))
    for U in links.values(): unitary=max(unitary,np.linalg.norm(U@U.conj().T-I,2))
    rows=[]; matrices=[]; avgs=[]
    for c,(P,loops) in enumerate(words):
        M,R,y=raw(P,loops); matrices.append(R); avgs.append(M)
        A=R[:,3*c:3*c+3]; prefix,_=word(P[:-1],False); T=ad(prefix)
        off=R.copy(); off[:,3*c:3*c+3]=0
        rows.append({'coarse_row':c,'y':float(y),'selected_error':float(np.linalg.norm(A-alpha*T,2)),
            'error_bound_9y':float(9*y),'inverse_norm':float(np.linalg.norm(np.linalg.inv(A),2)),
            'inverse_bound':float(2/alpha),'off_diagonal_norm':float(np.linalg.norm(off,2))})
    # One independently differenced wrapped selected column; no step/seed tuning.
    fd_error=0.; h=1e-5
    for c,(P,loops) in enumerate(words):
        plus,_,_=raw(P,loops,False,(17,2,h)); minus,_,_=raw(P,loops,False,(17,2,-h))
        fd=(lg(plus@avgs[c].conj().T)-lg(minus@avgs[c].conj().T))/(2*h)
        fd_error=max(fd_error,float(np.linalg.norm(fd-matrices[c][:,53])))
    tests={'curvature':curvature<=a0+1e-10,'unitarity':unitary<=1e-10,
        'selected_error':all(r['selected_error']<=r['error_bound_9y']+1e-10 for r in rows),
        'inverse':all(r['inverse_norm']<=r['inverse_bound']+1e-10 for r in rows),
        'off_diagonal':all(r['off_diagonal_norm']<=1e-10 for r in rows),'finite_difference':fd_error<=1e-8}
    tests={k:bool(v) for k,v in tests.items()}
    return {'L':L,'background':background,'dimension':2,'coarse_period':3,'seed':1701,'alpha':alpha,
        'a0':a0,'curvature':float(curvature),'unitarity':float(unitary),'finite_difference_error':fd_error,
        'tests':tests,'rows':rows,'passed':all(tests.values())}
start=time.time(); cases=[]
try:
    for L in [2,3]:
        for bg in ['flat','noncommuting']:
            c=run_case(L,bg); cases.append(c)
            print(json.dumps({k:c[k] for k in ['L','background','curvature','finite_difference_error','tests','passed']}),flush=True)
    result={'scope':'Floating-point SU2 raw-contour falsifier only; not interval proof, independent review, physical-family matching or hRpoly',
        'python':platform.python_version(),'numpy':np.__version__,'platform':platform.platform(),'duration_seconds':time.time()-start,
        'cases':cases,'all_passed':all(c['passed'] for c in cases)}
except Exception as e:
    result={'scope':'Failed/incomplete bounded run; preserve error and completed cases','error':repr(e),'cases':cases,'all_passed':False}
(HERE/'RESULT1415B.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
sys.exit(0 if result['all_passed'] else 1)
