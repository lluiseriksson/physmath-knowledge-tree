# Research capsule: Bounded raw-contour SU2 falsifier

- **Generated:** 2026-10-30T16:41:28.452Z
- **Workspace:** `workspace.raw-unit1415`
- **Dossier fingerprint:** `d405afefd1eae8842d6f15528363e8b280cf12f4c262baf1be3fe87adc89f4ec`
- **Capsule fingerprint:** `71896f795b007b476b2d592646c0938467cd642756abfbaf433b818ebb1227de`
- **Readiness:** **blocked**

## Capsule gates

| Gate | State | Progress | Detail |
| --- | --- | ---: | --- |
| Dossier readiness | attention | 0/1 | The source dossier still contains attention gates. |
| Run selection | ready | 2/2 | 2 selected runs are linked to the dossier scope. |
| Run fingerprints | ready | 2/2 | Every selected run fingerprint verifies. |
| Artifact integrity | attention | 1/2 | 1 terminal runs lack complete artifact hashes or byte counts. |
| Execution outcome | blocked | 1/2 | 1 selected runs failed or timed out. |
| Scope coverage | ready | 1/1 | Every dossier node is linked to at least one selected run. |
| Execution provenance | ready | 2/2 | Every selected run records a git commit and toolchain. |

## Dossier scope

- Canonical nodes: 1
- Induced edges: 0
- Dossier readiness: attention

- **Uniform one-step Yang-Mills RG activity bound** (`problem.uniform_yang_mills_rg_activity`)

## Selected runs

### Frozen four-case raw SU2 derivative falsifier

- ID: `run.raw-unit1415`
- Status: **failed**
- Kind: python
- Scope linked: yes
- Fingerprint verified: yes
- Artifacts complete: no
- Command: `C:/Python312/python.exe .run-ledger/raw-unit1415/probe1415.py`

- input: `.run-ledger/raw-unit1415/probe1415.py` — `aaaaae4cb616c2f83d888516c80972a0c3dbcc99373c40af9552d39147cc1807` (6082 bytes)
- input: `.run-ledger/raw-unit1415/PREREG1415.md` — `097dbaab3d591643e27059396af36afeffb39224cb78ac6328f838893958a304` (2324 bytes)
- input: `.run-ledger/raw-unit1415/FREEZE1415.json` — `b3c4c96cc6597c6edaea9ac05480e0020714351690c4b79d0414c955532f37e7` (539 bytes)
- input: `.run-ledger/raw-unit1415/DOSSIER1415.json` — `f37fe4dc9fc9d44038cb29230e878ebf1c8cbc40ce843c6f7489b45fb0993852` (19764 bytes)
- output: `.run-ledger/raw-unit1415/RESULT1415.json` — missing SHA-256
- log: `.run-ledger/raw-unit1415/logs/stdout.log` — `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` (0 bytes)
- log: `.run-ledger/raw-unit1415/logs/stderr.log` — `ce18335bd9638526f204d998db9d839b5e73c5474729a6b31b78189ce8895ead` (1366 bytes)

### Raw SU2 derivative falsifier with disclosed bool serialization repair

- ID: `run.raw-unit1415b`
- Status: **passed**
- Kind: python
- Scope linked: yes
- Fingerprint verified: yes
- Artifacts complete: yes
- Command: `C:/Python312/python.exe .run-ledger/raw-unit1415/probe1415b.py`

- input: `.run-ledger/raw-unit1415/probe1415b.py` — `57a7a75181798447f132f523659acb7c1fb06173365c1d6cc46a9ff73edf8387` (6252 bytes)
- input: `.run-ledger/raw-unit1415/PREREG1415.md` — `097dbaab3d591643e27059396af36afeffb39224cb78ac6328f838893958a304` (2324 bytes)
- input: `.run-ledger/raw-unit1415/FREEZE1415.json` — `b3c4c96cc6597c6edaea9ac05480e0020714351690c4b79d0414c955532f37e7` (539 bytes)
- input: `.run-ledger/raw-unit1415/AMENDMENT1415B.json` — `d44101ac4472db3f144db5b7bfaaab26595d8a21d9c052c2a53def0a2eb6e242` (583 bytes)
- output: `.run-ledger/raw-unit1415/RESULT1415B.json` — `0637dfa05bb68328ada4b1554a44a11a4b61638e0b3f8bfaad9b75fbfcda01c7` (25069 bytes)
- log: `.run-ledger/raw-unit1415/logs-b/stdout.log` — `a6568e8dd63289c449c6a54a857b89d9b4c948f3622be62f3ae1a06140600794` (1111 bytes)
- log: `.run-ledger/raw-unit1415/logs-b/stderr.log` — `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` (0 bytes)

## Open actions

- **blocked · outcome:** Resolve a failed run — Status failed; exit 1.
- **attention · artifact:** Content-address terminal artifacts — Record SHA-256 and byte size for every terminal-run artifact.
- **attention · dossier:** Resolve dossier attention gates — Address the dossier actions before treating the capsule as release-ready.

## Boundary

This capsule verifies the recorded dossier, run manifests and artifact metadata. It does not by itself prove a mathematical claim, validate scientific novelty or promote canonical graph confidence.

